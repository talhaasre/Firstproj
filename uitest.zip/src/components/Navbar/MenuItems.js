export const MenuItems = [
    {
        title: 'Home',
        url: '#',
        cName: 'nav-links'
    },
    {
        title: 'Consulting',
        url: '#',
        cName: 'nav-links'
    },
    {
        title: 'Training',
        url: '#',
        cName: 'nav-links'
    },
    {
        title: 'Examinations',
        url: '#',
        cName: 'nav-links'
    },
    {
        title: 'Knowledge Center',
        url: '#',
        cName: 'nav-links'
    },
    {
        title: 'Clients',
        url: '#',
        cName: 'nav-links'
    },
    {
        title: 'Company',
        url: '#',
        cName: 'nav-links'
    },
    {
        title: 'Register',
        url: '#',
        cName: 'nav-links-mobile'
    },
]